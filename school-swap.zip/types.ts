export interface User {
  id: string;
  name: string;
  avatarUrl: string;
  school: string;
  transactionCount: number;
  offers: string[];
}

export enum PostStatus {
  AVAILABLE = 'Available',
  COMPLETED = 'Completed',
  UNAVAILABLE = 'Unavailable',
}

export interface Post {
  id: string;
  author: User;
  title: string;
  description: string;
  category: string;
  imageUrl?: string;
  status: PostStatus;
  interestedUsers: string[];
  timestamp: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
}

export interface Conversation {
  id: string;
  participants: User[];
  messages: Message[];
}

export interface Theme {
  name: string;
  background: string;
  gradientFrom?: string;
  gradientTo?: string;
  primary: string;
  secondary: string;
  accent: string;
  textPrimary: string;
  textSecondary: string;
  cardBg: string;
  buttonText: string;
}